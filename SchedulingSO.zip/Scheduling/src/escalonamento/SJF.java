package escalonamento;

import java.util.ArrayList; 
/**
 *
 * @author Billy Rodrigues , Willer Rodrigo
 */
public class SJF {
    /* Conteúdo exemplo do arquivo
        5 = numero de processos
        3 = quantum do RR
        3 10 2 -> 3 = tempo de chegada, 10 = burst time , 2 = Prioridade
        4 12 1
        9 15 2
        11 15 1
        12 8 5
    */
    private ArrayList<Processo> listaProcessosCopia;
    private ArrayList<Processo> listaParaOrdenar;
    private ArrayList<Processo> listaProcessosParaExecutar;
    private ArrayList<String> graficoSaida;
    private int tempo = 0;
    private int tempoVerificacaoChegada = 0;

    public SJF(ArrayList<Processo> listaProcessos) {
        copiaListaProcessos(listaProcessos);
        listaParaOrdenar = new ArrayList<Processo>();
        listaProcessosParaExecutar = new ArrayList<Processo>();
        graficoSaida = new ArrayList<String>();
        executaEscalonamento();
    }

    private void copiaListaProcessos(ArrayList<Processo> listaProcessos) {
        listaProcessosCopia = new ArrayList<Processo>();
        for (int i = 0; i < listaProcessos.size(); i++) {
            listaProcessosCopia.add(listaProcessos.get(i));
        }
    }

    private void executaEscalonamento() {
        while (!listaProcessosCopia.isEmpty() || listaProcessosParaExecutar.size() > 0) {
            if (processoChegou()) {
                atualizaFila();
            }
            if (temProcessoNaFila()) {
                executaProcesso();
                graficoSaida.add("C");
                graficoSaida.add("S");
            } else {
                graficoSaida.add("-");
            }
            atualizaTempo();
        }
    }

    private boolean processoChegou() {//Organizando a lista de processos
        listaParaOrdenar.clear();
        for (int i = 0; i < listaProcessosCopia.size(); i++) {
            if (listaProcessosCopia.get(i).getTempoChegada() <= tempo  && listaProcessosCopia.get(i).getTempoChegada() > tempoVerificacaoChegada) {
                listaParaOrdenar.add(listaProcessosCopia.get(i));
                listaProcessosCopia.remove(i);
                i--;
            }
        }
        if (listaParaOrdenar.size() >= 1) {
            return true;
        }
        return false;
    }

    private void atualizaFila() { // Vai verificar qual dos processos tem o menor tempo de execuçao
        for (int i = 0; i < listaParaOrdenar.size(); i++) {
            int tempoExecucaoParaOrdenar = listaParaOrdenar.get(i).getTempoExecucao();
            int localParaInserirOProcesso = 0;

            if (!listaProcessosParaExecutar.isEmpty()) {
                for (int j = 0; j < listaProcessosParaExecutar.size(); j++) {
                    if (tempoExecucaoParaOrdenar > listaProcessosParaExecutar.get(j).getTempoExecucao()) {
                        localParaInserirOProcesso++;
                    }
                    if (tempoExecucaoParaOrdenar == listaProcessosParaExecutar.get(j).getTempoExecucao()) {
                        if (listaParaOrdenar.get(i).getPrioridade() > listaProcessosParaExecutar.get(j).getPrioridade()) {
                            localParaInserirOProcesso++;
                        }
                    }
                }
            }
            listaProcessosParaExecutar.add(localParaInserirOProcesso, listaParaOrdenar.get(i));
            listaParaOrdenar.remove(i);
            i--;
        }
    }

    private boolean temProcessoNaFila() {
        if (listaProcessosParaExecutar.isEmpty()) {
            return false;
        }
        return true;
    }

    private void executaProcesso() { //vai pegar otempo de execução e o numero do processo para printar no grafico
        int tempoExecucaoProcesso = listaProcessosParaExecutar.get(0).getTempoExecucao();
        int numeroDoProcesso = listaProcessosParaExecutar.get(0).getNumeroProcesso();
        for (int i = 0; i < tempoExecucaoProcesso; i++) {
            graficoSaida.add(String.valueOf(numeroDoProcesso));
        }
        listaProcessosParaExecutar.remove(0);
    }

    private void atualizaTempo() {
        tempo = graficoSaida.size();
    }

    public ArrayList<String> getGraficoSaida() {
        return graficoSaida;
    }
}