package escalonamento;

import java.util.ArrayList;
/**
 *
 * @author Billy Rodrigues , Willer Rodrigo
 */
public class RoundRobin {
    /* Conteúdo exemplo do arquivo
        5 = numero de processos
        3 = quantum do RR
        3 10 2 -> 3 = tempo de chegada, 10 = burst time , 2 = Prioridade
        4 12 1
        9 15 2
        11 15 1
        12 8 5
    */
    /* Exemplos para editar o arquivo :
        5           5
        3           3
        3 10 2      3 10 2
        4 12 1      4 12 1
        9 15 2      9 15 2  
        3 16 1      11 15 1
        12 8 5      12 8 5
    */
    private ArrayList<Processo> listaProcessos;
    private ArrayList<Processo> listaProcessosCopia;
    private ArrayList<Processo> listaParaOrdenar;
    private ArrayList<Processo> listaProcessosParaExecutar;
    private ArrayList<String> graficoSaida;
    private int quantum;
    private int tempo = 0;

    public RoundRobin(ArrayList<Processo> listaProcessos, int quantum) {
        copiaListaProcessos(listaProcessos);//Copia a lista de processos passada
        this.listaProcessos = listaProcessos;
        this.quantum = quantum; //recebe o quantum passado
        listaParaOrdenar = new ArrayList<Processo>();//Criando arraylists
        listaProcessosParaExecutar = new ArrayList<Processo>();//Criando arraylists
        graficoSaida = new ArrayList<String>();//Criando arraylists
        executaEscalonamento();
    }

    private void copiaListaProcessos(ArrayList<Processo> listaProcessos) {
        listaProcessosCopia = new ArrayList<Processo>();
        for (int i = 0; i < listaProcessos.size(); i++) {
            listaProcessosCopia.add(listaProcessos.get(i));
        }
    }

    private void executaEscalonamento() {
        while (!listaProcessosCopia.isEmpty() || listaProcessosParaExecutar.size() > 0) { //se a lista de processos que foi copiada nao estiver vazia ou o tamanho da lista de processos >0
            if (processoChegou()) {
                atualizaFila();
            }
            if (temProcessoNaFila()) {
                executaProcesso();
                graficoSaida.add("C");
                graficoSaida.add("S");
            } else {
                graficoSaida.add("-");
            }
            atualizaTempo();
        }
    }

    private boolean processoChegou() {//Organizando a lista de processos
        for (int i = 0; i < listaProcessosCopia.size(); i++) { // i = 0 ate i<tamanho da lista de processos copia (pelo arquivo exemplo =  pois desconsideramos as 2 primeiras linhas) 
            if (listaProcessosCopia.get(i).getTempoChegada() <= tempo){
                listaParaOrdenar.add(listaProcessosCopia.get(i));
                listaProcessosCopia.remove(i);
                i--;
            }
        }
        return listaParaOrdenar.size() >= 1;
    }

    private void atualizaFila() { // Vai verificar qual dos processos tem maior prioridade
        for (int i = 0; i < listaParaOrdenar.size(); i++) { 
            int prioridadeParaOrdenar = listaParaOrdenar.get(i).getPrioridade();// pega-se a prioridade do processo que esta na ArrayList para ordenar
            int localParaInserirOProcesso = 0;

            if (!listaProcessosParaExecutar.isEmpty()) {
                for (int j = 0; j < listaProcessosParaExecutar.size(); j++) {
                    if (prioridadeParaOrdenar >= listaProcessosParaExecutar.get(j).getPrioridade()) {
                        localParaInserirOProcesso++;
                    }
                }
            }
            listaProcessosParaExecutar.add(localParaInserirOProcesso, listaParaOrdenar.get(i));
            listaParaOrdenar.remove(i);
            i--;
        }
    }

    private boolean temProcessoNaFila() {
        if (listaProcessosParaExecutar.isEmpty()) {
            return false;
        }
        return true;
    }

    private void executaProcesso() {
        int tempoQueFaltaExecutar = listaProcessosParaExecutar.get(0).getTempoExecutar();
        int numeroDoProcesso = listaProcessosParaExecutar.get(0).getNumeroProcesso();
        int tempoExecutado = 0;

        if (tempoQueFaltaExecutar >= quantum) {
            for (int i = 0; i < quantum; i++) {
                graficoSaida.add(String.valueOf(numeroDoProcesso));
            }
            tempoExecutado = quantum;
        } else {
            for (int i = 0; i < tempoQueFaltaExecutar; i++) {
                graficoSaida.add(String.valueOf(numeroDoProcesso));
            }
            tempoExecutado = tempoQueFaltaExecutar;
        }
        listaProcessosParaExecutar.get(0).setTempoExecutado(tempoExecutado);

        if (listaProcessosParaExecutar.get(0).getTempoExecutar() == 0) {
            listaProcessosParaExecutar.remove(0);
        } else {
            Processo processo = listaProcessosParaExecutar.remove(0);
            listaParaOrdenar.add(processo);
            atualizaFila();
        }
    }

    private void atualizaTempo() {
        tempo = graficoSaida.size();
    }

    public ArrayList<String> getGraficoSaida() {
        return graficoSaida;
    }
}
