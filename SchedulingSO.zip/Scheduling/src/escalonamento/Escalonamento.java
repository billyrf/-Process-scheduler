package escalonamento;

import java.util.ArrayList;
/**
 *
 * @author Billy Rodrigues , Willer Rodrigo
 */
public class Escalonamento {
    /* Conteúdo exemplo do arquivo
        5 = numero de processos
        3 = quantum do RR
        3 10 2 -> 3 = tempo de chegada, 10 = burst time , 2 = Prioridade
        4 12 1
        9 15 2
        11 15 1
        12 8 5
    */
    public static void main(String[] args) {
      
        Arquivo scheduling = new Arquivo();
        scheduling.leArquivo("arquivo.txt");

        ArrayList<String> dadosArquivo = scheduling.pegaDadosDoArquivo(); //pega os dados dos processos presente no arquivo

        double tempoTotalExecucao;
        int qtdProcessos = Integer.parseInt(dadosArquivo.get(0));//Pega a primeira Linha do arquivo que equivale a quantidade de processos
        int quantum = Integer.parseInt(dadosArquivo.get(1));//Pega a segunda Lina do arquivo que equivale ao quantum do Round Robin

        GerenciadorProcessos gerenciador;
        gerenciador = new GerenciadorProcessos(qtdProcessos, quantum, dadosArquivo);
        gerenciador.adicionaProcessos(); //adiciona o processo 1 os dados do arquivo apos a segunda linha do arquivo
        
        //System.out.println("Tamanho dos dados do arquivo"); [
        //System.out.println(dadosArquivo.size());              [ Usado para verificar o numero de linhas presentes no arquivo
        
        ArrayList<Processo> listaProcessos = gerenciador.getListaProcessos();

        //Execução do Shortest Job First
        gerenciador.attTempo(); //atualiza o tempo que ainda falta executar
        SJF sjf = new SJF(listaProcessos);

        ArrayList<String> graficoSaidaSJF = sjf.getGraficoSaida();
        System.out.println("CS = Indica todas as vezes que trocamos de um processo para o outro");
        System.out.println("Gráfico de saída: SJF");
        for (int i = 0; i < graficoSaidaSJF.size(); i++) {
            System.out.print(graficoSaidaSJF.get(i));
        }
        System.out.println("");
        //System.out.println("");
        //System.out.print("Tamanho do grafico : ");    |
        //System.out.println(graficoSaidaSJF.size());   | Usado para conferir o calculo de Turnaround da calculadora
        //System.out.println(graficoSaidaSJF.get(36));  |
        System.out.println("");
        tempoTotalExecucao = 0;

        Calculadora calculadoraSJF = new Calculadora(listaProcessos, graficoSaidaSJF);
        for (int i = 0; i < listaProcessos.size(); i++) { //i = 0 ate i< tamanho da lista de proceessos
            System.out.println("Calculo para o processo " + listaProcessos.get(i).getNumeroProcesso()); // Vai ate a lista de processos e pegao numero do processo 
            calculadoraSJF.calculaTempoProcesso(listaProcessos.get(i));
            System.out.print("Tempo de Execução: ");//Desde o tempo em que ele entra no processo ate finaliza-lo
            System.out.println(calculadoraSJF.getTempoExecucao()); // Pega o tempo de turnaroud na classe Calculadora
            tempoTotalExecucao += calculadoraSJF.getTempoExecucao();
            System.out.println("--------------------------");
        }

        System.out.print("Tempo médio de Execução: ");
        System.out.println(tempoTotalExecucao / qtdProcessos);
        
        //Execução do Round Robin
        gerenciador.attTempo();///atualiza o tempo que ainda falta executar
        RoundRobin roundrobin = new RoundRobin(listaProcessos, quantum); //Envia para a classe RoundRobin a lista de processos criada e o quantum neceessario

        ArrayList<String> graficoSaidaRR = roundrobin.getGraficoSaida();
        
        System.out.println("");
        System.out.println("");
        System.out.println("Gráfico de saída: RoundRobin organizado por prioridade");
        for (int i = 0; i < graficoSaidaRR.size(); i++) {
            System.out.print(graficoSaidaRR.get(i));
        }

        System.out.println("");
        //System.out.println("Tamanho da lista de processos copia");
        //System.out.println(listaProcessos.size());
        System.out.println("");
        tempoTotalExecucao = 0;

        Calculadora calculadoraRoundRobin = new Calculadora(listaProcessos, graficoSaidaRR);
        for (int i = 0; i < listaProcessos.size(); i++) {//i = 0 ate i< tamanho da lista de processos
            System.out.println("Calculo para o processo " + listaProcessos.get(i).getNumeroProcesso());// Vai ate a lista de processos e pegao numero do processo 
            calculadoraRoundRobin.calculaTempoProcesso(listaProcessos.get(i));
            
            System.out.print("Tempo de Execução: ");
            System.out.println(calculadoraRoundRobin.getTempoExecucao());//Desde o tempo em que ele entra no processo ate finaliza-lo
            tempoTotalExecucao += calculadoraRoundRobin.getTempoExecucao();// Pega o tempo de turnaroud na classe Calculadora
            
            System.out.println("--------------------------");
        }
        System.out.print("Tempo médio de Execução: ");
        System.out.println(tempoTotalExecucao / qtdProcessos);
        
        //Execução do Priority Security
        gerenciador.attTempo();//atualiza o tempo que ainda falta executar
        PS prioritySecurity = new PS(listaProcessos); /*Envia para a classe PrioritySecurity a lista de processos criada e o quantum neceessario*/

        ArrayList<String> graficoSaidaPS = prioritySecurity.getGraficoSaida();
        
        System.out.println("");
        System.out.println("");
        System.out.println("Gráfico de saída: PrioritySecurity");
        for (int i = 0; i < graficoSaidaPS.size(); i++) {
            System.out.print(graficoSaidaPS.get(i));
        }

        System.out.println("");
        //System.out.println("Tamanho da lista de processos copia");
        //System.out.println(listaProcessos.size());
        System.out.println("");
        tempoTotalExecucao = 0;

        Calculadora calculadoraPS = new Calculadora(listaProcessos, graficoSaidaPS);
        for (int i = 0; i < listaProcessos.size(); i++) {//i = 0 ate i< tamanho da lista de processos
            System.out.println("Calculo para o processo " + listaProcessos.get(i).getNumeroProcesso());// Vai ate a lista de processos e pegao numero do processo 
            calculadoraPS.calculaTempoProcesso(listaProcessos.get(i));
            
            System.out.print("Tempo de Execução: ");
            System.out.println(calculadoraPS.getTempoExecucao());//Desde o tempo em que ele entra no processo ate finaliza-lo
            tempoTotalExecucao += calculadoraPS.getTempoExecucao();// Pega o tempo de turnaroud na classe Calculadora
            
            System.out.println("--------------------------");
        }
        System.out.print("Tempo médio de Execução: ");
        System.out.println(tempoTotalExecucao / qtdProcessos);
        
        //Execução do First-Come First Served 
        gerenciador.attTempo();//atualiza o tempo que ainda falta executar
        FCFS fcfs = new FCFS(listaProcessos); /*Envia para a classe PrioritySecurity a lista de processos criada e o quantum neceessario*/

        ArrayList<String> graficoSaidaFCFS = fcfs.getGraficoSaida();
        
        System.out.println("");
        System.out.println("");
        System.out.println("Gráfico de saída: First-Come First Served");
        for (int i = 0; i < graficoSaidaFCFS.size(); i++) {
            System.out.print(graficoSaidaFCFS.get(i));
        }

        System.out.println("");
        //System.out.println("Tamanho da lista de processos copia");
        //System.out.println(listaProcessos.size());
        System.out.println("");
        tempoTotalExecucao = 0;

        Calculadora calculadoraFCFS = new Calculadora(listaProcessos, graficoSaidaPS);
        for (int i = 0; i < listaProcessos.size(); i++) {//i = 0 ate i< tamanho da lista de processos
            System.out.println("Calculo para o processo " + listaProcessos.get(i).getNumeroProcesso());// Vai ate a lista de processos e pegao numero do processo 
            calculadoraFCFS.calculaTempoProcesso(listaProcessos.get(i));
            
            System.out.print("Tempo de Execução: ");
            System.out.println(calculadoraFCFS.getTempoExecucao());//Desde o tempo em que ele entra no processo ate finaliza-lo
            tempoTotalExecucao += calculadoraFCFS.getTempoExecucao();// Pega o tempo de turnaroud na classe Calculadora
            
            System.out.println("--------------------------");
        }
        System.out.print("Tempo médio de Execução: ");
        System.out.println(tempoTotalExecucao / qtdProcessos);
    }
}
    

