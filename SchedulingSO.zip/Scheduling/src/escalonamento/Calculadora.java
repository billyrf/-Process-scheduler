package escalonamento;

import java.util.ArrayList;
/**
 *
 * @author Billy Rodrigues , Willer Rodrigo
 */
public class Calculadora {
    /* Conteúdo exemplo do arquivo
        5 = numero de processos
        3 = quantum do RR
        3 10 2 -> 3 = tempo de chegada, 10 = burst time , 2 = Prioridade /
        4 12 1                                                           /
        9 15 2                                                           / 5 Processos
        11 15 1                                                          /
        12 8 5                                                           /
    */
    private ArrayList<Processo> listaProcessos;
    private ArrayList<String> graficoSaida;
    private int tempoExecucao;

    public Calculadora(ArrayList<Processo> listaProcessos, ArrayList<String> graficoSaida) {
        this.listaProcessos = listaProcessos;
        this.graficoSaida = graficoSaida;
        tempoExecucao = 0;
    }

    public void calculaTempoProcesso(Processo processo) {
        
        int tempoChegada = processo.getTempoChegada();//pega o tempo de chegada do processo passado EX : 
        int numeroProcesso = processo.getNumeroProcesso();//pega o numerp do processo passado EX : processo 1
        int fimProcesso = getFimProcesso(numeroProcesso); 
        
        tempoExecucao = fimProcesso - tempoChegada; //13-3 = 10
    }

    private int getFimProcesso(int numeroDoProcesso) { // Analise do processo 1 
        for (int i = graficoSaida.size() - 1; i > 0; i--) { // EX de grafico ---1111111111TC55555555TC222222222222TC444444444444444TC333333333333333TC size = 73
            if (graficoSaida.get(i).equals("" + numeroDoProcesso)) { // if graficoSaida.get(12).equals("" + numeroDoProcesso(1))
                return i + 1; // 12 +1 = 13 (agora retornamos para tempoExecucao)
            }
        }
        return -1;
    }

    public int getTempoExecucao() {
        return tempoExecucao;
    }
}
