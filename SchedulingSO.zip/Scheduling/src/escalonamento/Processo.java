package escalonamento;
/**
 *
 * @author Billy Rodrigues , Willer Rodrigo
 */
public class Processo {
    /* Conteúdo exemplo do arquivo
        5 = numero de processos
        3 = quantum do RR
        3 10 2 -> 3 = tempo de chegada, 10 = burst time , 2 = Prioridade
        4 12 1
        9 15 2
        11 15 1
        12 8 5
    */
    private int numeroDoProcesso;
    private int tempoChegada;
    private int tempoExecucao;
    private int tempoFaltaExecutar; //Tempo que falta para executar
    private int prioridade;

    public Processo(int numeroDoProcesso, int tempoDeChegada, int tempoDeExecucao, int prioridade) {
        this.numeroDoProcesso = numeroDoProcesso; //Recebe o numero do processo , EX : proceesso 1 , 2
        this.tempoChegada = tempoDeChegada; // pega o primeiro valor da linha. EX:3 10 2 -> 3 = tempo de chegada
        this.tempoExecucao = tempoDeExecucao;// pega o segundo valor da linha. EX:3 10 2 -> 10 = tempo de execução
        this.prioridade = prioridade;// pega o terceiro valor da linha. EX:3 10 2 -> 2 = prioridade
    }

    public int getTempoExecutar() {
        return tempoFaltaExecutar;
    }

    public void setTempoExecutado(int quantum) {
        this.tempoFaltaExecutar -= quantum; //tempo que falta para exxecutar no RR é o tempo de execuçao- o quantum
    }

    public void atualizaTempoExecutar() {
        tempoFaltaExecutar = tempoExecucao;
    }

    public int getTempoChegada() {
        return tempoChegada;
    }

    public int getTempoExecucao() {
        return tempoExecucao;
    }

    public int getPrioridade() {
        return prioridade;
    }

    public int getNumeroProcesso() {
        return numeroDoProcesso;
    }

}
