package escalonamento;

import java.util.ArrayList;
/**
 *
 * @author Billy Rodrigues , Willer Rodrigo
 */
class GerenciadorProcessos {
    /* Conteúdo exemplo do arquivo
        5 = numero de processos
        3 = quantum do RR
        3 10 2 -> 3 = tempo de chegada, 10 = burst time , 2 = Prioridade
        4 12 1
        9 15 2
        11 15 1
        12 8 5
    */
    private int qtdProcessos;
    private int tamanhoQuantum;
    private ArrayList<String> dadosArquivo;
    private ArrayList<Processo> listaProcessos;

    GerenciadorProcessos(int quantidadeProcessos, int tamanhoDoQuantum, ArrayList<String> dadosDoArquivo) {
        this.qtdProcessos = quantidadeProcessos;//reecebe a quantidade de proceessos presente no arquivo EX:5
        this.tamanhoQuantum = tamanhoDoQuantum; //reecebe o quantum presente no arquivo EX: 3
        this.dadosArquivo = dadosDoArquivo; 
        listaProcessos = new ArrayList<Processo>();
    }

    public void adicionaProcessos() {
        int numeroDoProcesso = 1;

        for (int i = 2; i < dadosArquivo.size(); i++) {//No arquivo dado como exxemplo i=2 e vai ate <7
            String[] lista = dadosArquivo.get(i).split(" "); //Quebra a string em varias substrings
            int tempoChegada = Integer.parseInt(lista[0]); // Tempo de chegada é igual ao primeiro numero a partir da 3 linha do arquivo
            int tempoExecucao = Integer.parseInt(lista[1]);// Tempo de execução é igual ao segundo numero a partir da 3 linha do arquivo
            int prioridade = Integer.parseInt(lista[2]);// Prioridade é igual ao terceiro numero a partir da 3 linha do arquivo
            listaProcessos.add(new Processo(numeroDoProcesso, tempoChegada, tempoExecucao, prioridade));

            numeroDoProcesso++; //Repetir o metodo para os 5 processos
        }
    }

    public ArrayList<Processo> getListaProcessos() {
        return listaProcessos;
    }

    public void attTempo() {
        for (int i = 0; i < listaProcessos.size(); i++) {
            listaProcessos.get(i).atualizaTempoExecutar();
        }
    }

}
